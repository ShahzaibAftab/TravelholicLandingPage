import './App.css';
import Home from './Components/Home/Home'
import Main from './Components/Main/Main'
import Navbar from './Components/Navbar/Navbar'
import Footer from './Components/Footer/Footer'
import AboutUs from './Components/AboutUs/AboutUs'
import Contact from './Components/ContactForm/ContactForm.jsx'
import {Route,Routes} from "react-router-dom";
function App() {
  return (
    <>
  <Navbar/>
  {/* <Home/>
  <Main/> */}
 <Routes>
  <Route path='/Home' element={<Home/>}/>
  <Route path='/' element={<Home/>}/>
  <Route path='/Main' element={<Main/>}/>
  <Route path='/About' element={<AboutUs/>}/>
  <Route path='/Contact' element={<Contact/>}/>
  </Routes>
  <Footer/> 
    </>
  );
}

export default App;
