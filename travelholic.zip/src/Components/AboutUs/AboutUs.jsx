import React from 'react'
import './AboutUs.css'
import {AiFillYoutube} from 'react-icons/ai'
import {AiFillTwitterCircle} from 'react-icons/ai'
import {AiFillFacebook} from 'react-icons/ai'

const aboutUs = () => {
  return (
    <section className='main-section'>
        <div className="about-section">
            <div className="inner-container">
                <h1>About Us</h1>
                <p className='text'>Lorem ipsum dolor sit amet consectetur adipisicing elit. Debitis maxime error similique, blanditiis magni suscipit animi quisquam totam dolores autem sapiente, aspernatur ab eius tempora numquam adipisci! Fuga, id provident! Lorem ipsum dolor, sit amet consectetur adipisicing elit. Perferendis, totam tempore! Tempore explicabo molestias quibusdam veritatis, unde quas dolor maxime nemo perspiciatis eveniet a dolore aut magnam incidunt provident iure.</p>
        <div className="socialIcons">
         <a className='setYoutube' href="g.com"><AiFillYoutube/></a>
         <a className='setTwitter' href="g.com"><AiFillTwitterCircle/></a>
         <a className='setFacebook' href="g.com"><AiFillFacebook/></a>
        </div>
            </div>
        </div>
    </section>
  )
}

export default aboutUs