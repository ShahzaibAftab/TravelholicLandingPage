import React, { useState } from 'react'
import './Navbar.css'
import { MdOutlineTravelExplore } from 'react-icons/md'
import {AiFillCloseCircle} from 'react-icons/ai'
import {TbGridDots} from 'react-icons/tb'

const Navbar = () => {
    const [active, setActive]=useState('navBar')
    //toggle navbar
    const showNav=()=>{
        setActive('navBar activeNavbar')        
    }
         //remove navbar
     const removeNavbar=()=>{
        
            setActive('navBar')
        }
  return (
   <section className='navbarSelection'>
<header className='header flex'>
<div className='logoDiv'>
<a href='google.com' className='logo flex'>
<h1><MdOutlineTravelExplore className='icon'/>Travelholic.pk</h1>
</a>
</div>

<div className={active}>
<ul className="navLists flex">
<li className="navItem">
<a href='/Home' className="navLink">Home</a>
</li>
<li className="navItem">
<a href="google.com" className="navLink">Plan Trip</a>
</li>
<li className="navItem">
<a href="google.com" className="navLink">Discounts</a>
</li>
<li className="navItem">
<a href='/About' className="navLink">About</a>
</li>
<li className="navItem">
<a href="google.com" className="navLink">Blog</a>
</li>
<li className="navItem">
<a href="google.com" className="navLink">News</a>
</li>
<li className="navItem">
<a href="/Contact" className="navLink">Contact</a>
</li>
<button className="btn" > 
<a href='google.com'>Book Now</a></button>
</ul>
<div onClick={removeNavbar} className='closeNavbar'>
<AiFillCloseCircle className="icon"></AiFillCloseCircle>
</div>

</div>
<div onClick={showNav} className="toggleNavbar">
    <TbGridDots className="icon"></TbGridDots>
</div>
</header>
   </section> 
 
 )
}

export default Navbar