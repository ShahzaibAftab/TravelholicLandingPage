import img3 from '../../Assets/images/eiffeltower.jpg'
import img5 from '../../Assets/images/karachi.jpg'
import img6 from '../../Assets/images/Kumratvalley.jpg'
import img8 from '../../Assets/images/murree.jpg'
import img9 from '../../Assets/images/swat.jpg'


// DataApi/////////ARRAY///OF//OBJECTS
const dataApi=[
  {
    id:1,
    imgSrc:img8,
    destTitle:'Abu Dhabi',
    location: 'UAE',
    grade:'CULTURAL RELAX',
    fees:'$700',
    description: 'ipContrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin'
  }
  ,
  {
    id:2,
    imgSrc:img9,
    destTitle:'Bad shahi',
    location: 'LHR',
    grade:'CULTURAL RELAX',
    fees:'$700',
    description: 'ip Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin'
  },
  {
    id:3,
    imgSrc:img3,
    destTitle:'Eiffel Tower',
    location: 'Paris',
    grade:'Travelling',
    fees:'$700',
    description: 'ip Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin'
  },
  {
    id:4,
    imgSrc:img6,
    destTitle:'Gilgit',
    location: 'Pakistan',
    grade:'CULTURAL RELAX',
    fees:'$700',
    description: 'ip Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin'
  },
  {
    id:5,
    imgSrc:img5,
    destTitle:'Karachi',
    location: 'Sindh',
    grade:'CULTURAL RELAX',
    fees:'$700',
    description: 'ip Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin'
  },
  {
    id:6,
    imgSrc:img6,
    destTitle:'Kumrat',
    location: 'Gilgit',
    grade:'CULTURAL RELAX',
    fees:'$700',
    description: 'ip Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin'
  },
  {
    id:7,
    imgSrc:img3,
    destTitle:'Badshahi',
    location: 'Punjab',
    grade:'CULTURAL RELAX',
    fees:'$700',
    description: 'ip Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin'
  },
  {
    id:8,
    imgSrc:img8,
    destTitle:'Muree',
    location: 'Islamabad',
    grade:'CULTURAL RELAX',
    fees:'$700',
    description: 'ipContrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin'
  },
  {
    id:9,
    imgSrc:img9,
    destTitle:'Green Valley',
    location: 'Swat',
    grade:'CULTURAL RELAX',
    fees:'$700',
    description: 'Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin'
  }
]
export default dataApi;