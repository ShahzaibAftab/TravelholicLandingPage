
import React from 'react'
import {GoLocation} from 'react-icons/go'
import {BsFillTelephoneFill} from 'react-icons/bs'
import {AiOutlineMail} from 'react-icons/ai'
import './ContactForm.css'

const ContactForm = () => {
  return ( <section className="contact">
      <div className="content">
        <h2>Contact Us</h2>
        <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Delectus eos quaerat natus 
        architecto quas ea praesentium laborum, in dolorem distinctio? Sapiente ullam dolores exercitationem sed ipsam.</p>
      </div>
      <div className="container">
        <div className="contactInfo">
        <div className="box">
          <div className="icon"> <GoLocation /> </div>
          <div className="text">
            <h3>Address</h3>
            <p>4544 Hall road,<br/>Multan Road <br/>4543</p>
          </div>
      </div>
          <div className="box">
          <div className="icon"><BsFillTelephoneFill /></div>
          <div className="text">
            <h3>Phone</h3>
            <p>4544 Hall road</p>
          </div>
        </div>
        <div className="box">
          <div className="icon"><AiOutlineMail />  </div>
          <div className="text">
            <h3>Email</h3>
            <p>4544 Hall road</p>
          </div>
        </div>
        </div>

        <div className="contactForm">
          <form>
            <h2>Leave your messege</h2>
            <div className="inputBox">
              <input type='text' />
              <span>Full name</span>
            </div>
            <div className="inputBox">
              <input type='text' />
              <span>Email</span>
            </div>
            <div className="inputBox">
              <textarea></textarea>
              <span>Enter your message</span>
            </div>
            <div className="inputBox">
              <input type='submit' value="submit"/>
            </div>

          </form>
        </div>
      </div>
    </section>
  )
}

export default ContactForm